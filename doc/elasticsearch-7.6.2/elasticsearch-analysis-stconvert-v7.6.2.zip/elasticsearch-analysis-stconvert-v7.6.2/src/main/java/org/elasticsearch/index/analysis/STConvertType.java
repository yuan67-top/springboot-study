package org.elasticsearch.index.analysis;

public enum STConvertType {
    SIMPLE_2_TRADITIONAL,
    TRADITIONAL_2_SIMPLE,
}
